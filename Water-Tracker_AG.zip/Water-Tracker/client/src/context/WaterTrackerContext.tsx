import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import type { WaterTrackerState } from "@shared/schema";

interface WaterTrackerContextType {
  state: WaterTrackerState;
  addWater: (amount: number) => void;
  setFrequency: (frequency: number) => void;
  setMood: (mood: "sad" | "neutral" | "happy") => void;
  setWaterType: (type: "still" | "carbonated" | "flavored") => void;
  setDailyGoal: (goal: number) => void;
  resetDaily: () => void;
  getProgress: () => number;
  getMilestone: () => number;
}

const WaterTrackerContext = createContext<WaterTrackerContextType | undefined>(undefined);

const DEFAULT_STATE: WaterTrackerState = {
  currentIntake: 0,
  dailyGoal: 2000,
  frequency: null,
  mood: null,
  waterType: null,
};

export function WaterTrackerProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WaterTrackerState>(DEFAULT_STATE);

  const addWater = useCallback((amount: number) => {
    setState((prev) => ({
      ...prev,
      currentIntake: Math.min(prev.currentIntake + amount, prev.dailyGoal),
    }));
  }, []);

  const setFrequency = useCallback((frequency: number) => {
    setState((prev) => ({ ...prev, frequency }));
  }, []);

  const setMood = useCallback((mood: "sad" | "neutral" | "happy") => {
    setState((prev) => ({ ...prev, mood }));
  }, []);

  const setWaterType = useCallback((type: "still" | "carbonated" | "flavored") => {
    setState((prev) => ({ ...prev, waterType: type }));
  }, []);

  const setDailyGoal = useCallback((goal: number) => {
    setState((prev) => ({ ...prev, dailyGoal: goal }));
  }, []);

  const resetDaily = useCallback(() => {
    setState(DEFAULT_STATE);
  }, []);

  const getProgress = useCallback(() => {
    return Math.round((state.currentIntake / state.dailyGoal) * 100);
  }, [state.currentIntake, state.dailyGoal]);

  const getMilestone = useCallback(() => {
    const progress = (state.currentIntake / state.dailyGoal) * 100;
    if (progress >= 100) return 4;
    if (progress >= 75) return 3;
    if (progress >= 50) return 2;
    if (progress >= 25) return 1;
    return 0;
  }, [state.currentIntake, state.dailyGoal]);

  return (
    <WaterTrackerContext.Provider
      value={{
        state,
        addWater,
        setFrequency,
        setMood,
        setWaterType,
        setDailyGoal,
        resetDaily,
        getProgress,
        getMilestone,
      }}
    >
      {children}
    </WaterTrackerContext.Provider>
  );
}

export function useWaterTracker() {
  const context = useContext(WaterTrackerContext);
  if (context === undefined) {
    throw new Error("useWaterTracker must be used within a WaterTrackerProvider");
  }
  return context;
}
