import { PageLayout } from "@/components/PageLayout";
import { WaterGlass } from "@/components/WaterGlass";
import { useWaterTracker } from "@/context/WaterTrackerContext";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Plus } from "lucide-react";
import { WATER_AMOUNTS } from "@shared/schema";

export default function DailyGoal() {
  const { state, addWater, getProgress } = useWaterTracker();
  const progress = getProgress();

  return (
    <PageLayout showNav title="Daily Goal">
      <div className="max-w-md mx-auto px-6 py-8">
        <section className="flex flex-col items-center mb-10">
          <WaterGlass size="large" showMilestones />
        </section>

        <section className="mb-8">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-muted-foreground">Progress</span>
            <span className="text-sm font-semibold text-foreground" data-testid="text-progress">
              {progress}%
            </span>
          </div>
          <Progress value={progress} className="h-4" data-testid="progress-bar" />
        </section>

        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="text-center">
              <div 
                className="text-4xl font-bold text-foreground mb-1"
                data-testid="text-current-intake"
              >
                {state.currentIntake} ml
              </div>
              <div className="text-sm text-muted-foreground">Current</div>
            </div>
            <div className="w-px h-12 bg-border" />
            <div className="text-center">
              <div 
                className="text-4xl font-bold text-primary mb-1"
                data-testid="text-goal"
              >
                {state.dailyGoal / 1000} L
              </div>
              <div className="text-sm text-muted-foreground">Goal (100%)</div>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-foreground mb-4">Add Water</h2>
          <div className="grid grid-cols-3 gap-3">
            {WATER_AMOUNTS.map((amount) => (
              <Button
                key={amount}
                variant="outline"
                size="lg"
                className="h-14 text-base font-medium flex flex-col gap-1"
                onClick={() => addWater(amount)}
                disabled={state.currentIntake >= state.dailyGoal}
                data-testid={`button-add-${amount}`}
              >
                <Plus className="w-4 h-4" />
                {amount} ml
              </Button>
            ))}
          </div>
          
          {state.currentIntake >= state.dailyGoal && (
            <div 
              className="text-center py-4 px-4 bg-primary/10 rounded-lg border border-primary/20"
              data-testid="text-goal-reached"
            >
              <span className="text-primary font-semibold">
                Congratulations! You reached your daily goal!
              </span>
            </div>
          )}
        </section>
      </div>
    </PageLayout>
  );
}
