import { Link } from "wouter";
import { WaterDropIcon } from "@/components/WaterDropIcon";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <div className="max-w-md w-full flex flex-col items-center text-center">
        <div className="mb-8">
          <WaterDropIcon className="w-36 h-48" animated />
        </div>
        
        <h1 
          className="text-3xl font-bold text-foreground mb-3"
          data-testid="text-title"
        >
          Water Tracker
        </h1>
        
        <p 
          className="text-muted-foreground mb-10 text-lg"
          data-testid="text-subtitle"
        >
          Stay hydrated, stay healthy
        </p>
        
        <Link href="/daily-goal">
          <Button 
            size="lg" 
            className="gap-2 text-base"
            data-testid="button-start"
          >
            Start Tracking
            <ArrowRight className="w-5 h-5" />
          </Button>
        </Link>
        
        <div className="mt-12 grid grid-cols-4 gap-4 w-full">
          <FeatureCard 
            icon={<DropletIcon />}
            label="Track Water"
          />
          <FeatureCard 
            icon={<ChartIcon />}
            label="Set Goals"
          />
          <FeatureCard 
            icon={<MoodIcon />}
            label="Log Mood"
          />
          <FeatureCard 
            icon={<TypeIcon />}
            label="Water Type"
          />
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex flex-col items-center gap-2 p-3 rounded-lg bg-card border border-card-border">
      <div className="w-8 h-8 text-primary">{icon}</div>
      <span className="text-xs text-muted-foreground font-medium text-center">{label}</span>
    </div>
  );
}

function DropletIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-full h-full">
      <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
    </svg>
  );
}

function ChartIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-full h-full">
      <path d="M3 3v18h18" />
      <path d="M7 16l4-8 4 4 6-6" />
    </svg>
  );
}

function MoodIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-full h-full">
      <circle cx="12" cy="12" r="10" />
      <path d="M8 14s1.5 2 4 2 4-2 4-2" />
      <line x1="9" y1="9" x2="9.01" y2="9" />
      <line x1="15" y1="9" x2="15.01" y2="9" />
    </svg>
  );
}

function TypeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-full h-full">
      <path d="M4.5 3h15l-1.5 9H6L4.5 3Z" />
      <path d="M6 12l-.5 3a2 2 0 0 0 2 2.5h9a2 2 0 0 0 2-2.5L18 12" />
      <path d="M11 12v9" />
      <path d="M7 21h10" />
    </svg>
  );
}
