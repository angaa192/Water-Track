import { PageLayout } from "@/components/PageLayout";
import { useWaterTracker } from "@/context/WaterTrackerContext";
import { MOOD_OPTIONS } from "@shared/schema";
import { Frown, Meh, Smile, Check } from "lucide-react";

const moodConfig = {
  sad: {
    icon: Frown,
    label: "Not Great",
    bgColor: "bg-red-500 dark:bg-red-600",
    selectedBg: "bg-red-500/20 dark:bg-red-600/20",
    borderColor: "border-red-500 dark:border-red-600",
    textColor: "text-red-600 dark:text-red-400",
  },
  neutral: {
    icon: Meh,
    label: "Okay",
    bgColor: "bg-yellow-500 dark:bg-yellow-500",
    selectedBg: "bg-yellow-500/20 dark:bg-yellow-500/20",
    borderColor: "border-yellow-500 dark:border-yellow-500",
    textColor: "text-yellow-600 dark:text-yellow-400",
  },
  happy: {
    icon: Smile,
    label: "Great",
    bgColor: "bg-green-500 dark:bg-green-500",
    selectedBg: "bg-green-500/20 dark:bg-green-500/20",
    borderColor: "border-green-500 dark:border-green-500",
    textColor: "text-green-600 dark:text-green-400",
  },
};

export default function Mood() {
  const { state, setMood } = useWaterTracker();

  return (
    <PageLayout showNav title="Mood">
      <div className="max-w-md mx-auto px-6 py-8">
        <section className="text-center mb-10">
          <h2 
            className="text-2xl font-bold text-foreground mb-2"
            data-testid="text-question"
          >
            How do you feel today?
          </h2>
          <p className="text-muted-foreground">
            Hydration affects your mood and energy levels
          </p>
        </section>

        <section className="flex justify-center gap-6 mb-10">
          {MOOD_OPTIONS.map((mood) => {
            const config = moodConfig[mood];
            const Icon = config.icon;
            const isSelected = state.mood === mood;

            return (
              <button
                key={mood}
                onClick={() => setMood(mood)}
                className={`relative flex flex-col items-center gap-3 p-4 rounded-xl transition-all duration-300 ${
                  isSelected
                    ? `${config.selectedBg} border-2 ${config.borderColor}`
                    : "bg-card border-2 border-card-border"
                }`}
                data-testid={`button-mood-${mood}`}
                aria-label={`Select mood: ${config.label}`}
              >
                <div
                  className={`w-16 h-16 rounded-full flex items-center justify-center ${config.bgColor}`}
                >
                  <Icon className="w-8 h-8 text-white" strokeWidth={2.5} />
                </div>
                
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                    isSelected
                      ? `${config.borderColor} ${config.bgColor}`
                      : "border-muted"
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
              </button>
            );
          })}
        </section>

        <section className="text-center">
          <p className="text-sm text-muted-foreground mb-2">Click to choose option</p>
          
          {state.mood !== null && (
            <div 
              className={`mt-6 py-4 px-4 rounded-lg border ${moodConfig[state.mood].selectedBg} ${moodConfig[state.mood].borderColor}`}
              data-testid="text-mood-selected"
            >
              <span className={`font-semibold ${moodConfig[state.mood].textColor}`}>
                You're feeling {moodConfig[state.mood].label.toLowerCase()} today
              </span>
            </div>
          )}
        </section>
      </div>
    </PageLayout>
  );
}
