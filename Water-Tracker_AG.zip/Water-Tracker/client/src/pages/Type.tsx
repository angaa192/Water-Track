import { PageLayout } from "@/components/PageLayout";
import { useWaterTracker } from "@/context/WaterTrackerContext";
import { Button } from "@/components/ui/button";
import { WATER_TYPES } from "@shared/schema";
import { Check } from "lucide-react";

const typeConfig = {
  still: {
    label: "Still",
    description: "Plain water",
    gradient: "from-blue-200 to-blue-400 dark:from-blue-400 dark:to-blue-600",
  },
  carbonated: {
    label: "Carbonated",
    description: "Sparkling water",
    gradient: "from-slate-300 to-blue-300 dark:from-slate-400 dark:to-blue-400",
  },
  flavored: {
    label: "Flavored",
    description: "Infused water",
    gradient: "from-green-200 to-green-400 dark:from-green-400 dark:to-green-600",
  },
};

export default function Type() {
  const { state, setWaterType } = useWaterTracker();

  return (
    <PageLayout showNav title="Water Type">
      <div className="max-w-md mx-auto px-6 py-8">
        <section className="flex justify-center gap-4 mb-10">
          {WATER_TYPES.map((type) => (
            <WaterTypeGlass 
              key={type} 
              type={type} 
              isSelected={state.waterType === type}
            />
          ))}
        </section>

        <section className="text-center mb-10">
          <h2 
            className="text-2xl font-bold text-foreground mb-2"
            data-testid="text-question"
          >
            What type of water did you drink?
          </h2>
          <p className="text-muted-foreground">
            Different waters have different benefits
          </p>
        </section>

        <section className="space-y-3">
          {WATER_TYPES.map((type) => {
            const config = typeConfig[type];
            const isSelected = state.waterType === type;

            return (
              <Button
                key={type}
                variant={isSelected ? "default" : "outline"}
                size="lg"
                className="w-full h-14 text-base font-medium justify-between"
                onClick={() => setWaterType(type)}
                data-testid={`button-type-${type}`}
              >
                <div className="flex flex-col items-start">
                  <span>{config.label}</span>
                  <span className="text-xs opacity-70">{config.description}</span>
                </div>
                {isSelected && <Check className="w-5 h-5" />}
              </Button>
            );
          })}
        </section>

        {state.waterType !== null && (
          <section className="mt-8 text-center">
            <div 
              className="py-4 px-4 bg-card rounded-lg border border-card-border"
              data-testid="text-type-selected"
            >
              <span className="text-foreground">
                You prefer <span className="font-semibold text-primary">{typeConfig[state.waterType].label.toLowerCase()}</span> water
              </span>
            </div>
          </section>
        )}
      </div>
    </PageLayout>
  );
}

interface WaterTypeGlassProps {
  type: "still" | "carbonated" | "flavored";
  isSelected: boolean;
}

function WaterTypeGlass({ type, isSelected }: WaterTypeGlassProps) {
  return (
    <div className={`transition-transform duration-300 ${isSelected ? "scale-110" : "scale-100 opacity-70"}`}>
      <svg
        viewBox="0 0 60 80"
        className="w-16 h-20"
        aria-label={`${type} water glass`}
      >
        <defs>
          <clipPath id={`typeClip-${type}`}>
            <path d="M10 8 L50 8 L47 72 L13 72 Z" />
          </clipPath>
          <linearGradient id={`typeGrad-${type}`} x1="0%" y1="0%" x2="0%" y2="100%">
            {type === "still" && (
              <>
                <stop offset="0%" stopColor="hsl(195, 80%, 75%)" />
                <stop offset="100%" stopColor="hsl(200, 80%, 55%)" />
              </>
            )}
            {type === "carbonated" && (
              <>
                <stop offset="0%" stopColor="hsl(200, 20%, 75%)" />
                <stop offset="100%" stopColor="hsl(200, 40%, 65%)" />
              </>
            )}
            {type === "flavored" && (
              <>
                <stop offset="0%" stopColor="hsl(140, 60%, 75%)" />
                <stop offset="100%" stopColor="hsl(150, 60%, 55%)" />
              </>
            )}
          </linearGradient>
        </defs>

        <path
          d="M10 8 L50 8 L47 72 L13 72 Z"
          fill="none"
          stroke={isSelected ? "hsl(var(--primary))" : "hsl(var(--border))"}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        <g clipPath={`url(#typeClip-${type})`}>
          <rect x="10" y="30" width="40" height="42" fill={`url(#typeGrad-${type})`} />
          
          {type === "carbonated" && (
            <>
              <circle cx="20" cy="50" r="2" fill="rgba(255,255,255,0.6)">
                <animate attributeName="cy" values="50;35;50" dur="2s" repeatCount="indefinite" />
              </circle>
              <circle cx="30" cy="55" r="1.5" fill="rgba(255,255,255,0.5)">
                <animate attributeName="cy" values="55;40;55" dur="2.5s" repeatCount="indefinite" />
              </circle>
              <circle cx="40" cy="52" r="2" fill="rgba(255,255,255,0.6)">
                <animate attributeName="cy" values="52;38;52" dur="1.8s" repeatCount="indefinite" />
              </circle>
              <circle cx="25" cy="60" r="1" fill="rgba(255,255,255,0.4)">
                <animate attributeName="cy" values="60;42;60" dur="2.2s" repeatCount="indefinite" />
              </circle>
              <circle cx="35" cy="58" r="1.5" fill="rgba(255,255,255,0.5)">
                <animate attributeName="cy" values="58;45;58" dur="2.3s" repeatCount="indefinite" />
              </circle>
            </>
          )}
          
          {type === "flavored" && (
            <>
              <line x1="18" y1="35" x2="18" y2="65" stroke="hsl(120, 50%, 40%)" strokeWidth="1.5" opacity="0.6" />
              <line x1="22" y1="38" x2="22" y2="62" stroke="hsl(130, 50%, 45%)" strokeWidth="1" opacity="0.5" />
              <line x1="38" y1="36" x2="38" y2="64" stroke="hsl(125, 50%, 42%)" strokeWidth="1.5" opacity="0.6" />
              <line x1="42" y1="40" x2="42" y2="60" stroke="hsl(135, 50%, 45%)" strokeWidth="1" opacity="0.5" />
            </>
          )}
        </g>

        <line
          x1="12"
          y1="28"
          x2="48"
          y2="28"
          stroke="hsl(var(--border))"
          strokeWidth="1.5"
          opacity="0.5"
        />
      </svg>
    </div>
  );
}
