import { PageLayout } from "@/components/PageLayout";
import { useWaterTracker } from "@/context/WaterTrackerContext";
import { Button } from "@/components/ui/button";
import { FREQUENCY_OPTIONS } from "@shared/schema";
import { Check } from "lucide-react";

export default function Frequency() {
  const { state, setFrequency } = useWaterTracker();

  return (
    <PageLayout showNav title="Frequency">
      <div className="max-w-md mx-auto px-6 py-8">
        <section className="flex justify-center mb-10">
          <FrequencyGlass />
        </section>

        <section className="text-center mb-10">
          <h2 
            className="text-2xl font-bold text-foreground mb-2"
            data-testid="text-question"
          >
            How many times a day did you drink water?
          </h2>
          <p className="text-muted-foreground">
            Track your drinking frequency to build better habits
          </p>
        </section>

        <section className="space-y-3">
          {FREQUENCY_OPTIONS.map((times) => (
            <Button
              key={times}
              variant={state.frequency === times ? "default" : "outline"}
              size="lg"
              className="w-full h-14 text-base font-medium justify-between"
              onClick={() => setFrequency(times)}
              data-testid={`button-frequency-${times}`}
            >
              <span>
                {times} time{times > 1 ? "s" : ""}
              </span>
              {state.frequency === times && (
                <Check className="w-5 h-5" />
              )}
            </Button>
          ))}
        </section>

        {state.frequency !== null && (
          <section className="mt-8 text-center">
            <div 
              className="py-4 px-4 bg-card rounded-lg border border-card-border"
              data-testid="text-frequency-selected"
            >
              <span className="text-foreground">
                You drink water <span className="font-semibold text-primary">{state.frequency} time{state.frequency > 1 ? "s" : ""}</span> per day
              </span>
            </div>
          </section>
        )}
      </div>
    </PageLayout>
  );
}

function FrequencyGlass() {
  return (
    <div className="relative">
      <svg
        viewBox="0 0 100 120"
        className="w-28 h-36"
        aria-label="Glass with water"
      >
        <defs>
          <clipPath id="freqGlassClip">
            <path d="M20 10 L80 10 L75 110 L25 110 Z" />
          </clipPath>
          <linearGradient id="freqWaterGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="hsl(195, 85%, 75%)" />
            <stop offset="100%" stopColor="hsl(200, 85%, 55%)" />
          </linearGradient>
          <pattern id="freqWavePattern" patternUnits="userSpaceOnUse" width="60" height="10" x="0" y="0">
            <path d="M0 5 Q15 2 30 5 T60 5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="3">
              <animate
                attributeName="d"
                values="M0 5 Q15 2 30 5 T60 5;M0 5 Q15 8 30 5 T60 5;M0 5 Q15 2 30 5 T60 5"
                dur="1.5s"
                repeatCount="indefinite"
              />
            </path>
          </pattern>
        </defs>

        <path
          d="M20 10 L80 10 L75 110 L25 110 Z"
          fill="none"
          stroke="hsl(var(--border))"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        <g clipPath="url(#freqGlassClip)">
          <rect x="20" y="30" width="60" height="80" fill="url(#freqWaterGradient)" />
          <rect x="20" y="26" width="60" height="10" fill="url(#freqWavePattern)" />
        </g>
      </svg>

      <div className="absolute -right-4 top-1/2 -translate-y-1/2 text-4xl text-muted-foreground">
        ?
      </div>
    </div>
  );
}
