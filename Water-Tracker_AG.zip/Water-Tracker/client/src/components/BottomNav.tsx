import { useLocation, Link } from "wouter";
import { Droplets, RefreshCw, SmilePlus, Beaker } from "lucide-react";

const navItems = [
  { path: "/daily-goal", label: "Daily Goal", icon: Droplets },
  { path: "/frequency", label: "Frequency", icon: RefreshCw },
  { path: "/mood", label: "Mood", icon: SmilePlus },
  { path: "/type", label: "Type", icon: Beaker },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-card-border z-50">
      <div className="max-w-md mx-auto flex">
        {navItems.map((item) => {
          const isActive = location === item.path;
          const Icon = item.icon;

          return (
            <Link
              key={item.path}
              href={item.path}
              data-testid={`nav-${item.path.slice(1)}`}
              className={`flex-1 flex flex-col items-center justify-center py-3 gap-1 transition-colors duration-200 ${
                isActive
                  ? "text-primary"
                  : "text-muted-foreground"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
