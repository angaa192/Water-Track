interface WaterDropIconProps {
  className?: string;
  animated?: boolean;
}

export function WaterDropIcon({ className = "w-32 h-40", animated = true }: WaterDropIconProps) {
  return (
    <svg
      viewBox="0 0 100 130"
      className={className}
      aria-label="Water droplet"
    >
      <defs>
        <linearGradient id="dropGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="hsl(195, 85%, 75%)" />
          <stop offset="50%" stopColor="hsl(200, 85%, 55%)" />
          <stop offset="100%" stopColor="hsl(205, 85%, 45%)" />
        </linearGradient>
        <filter id="dropShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.15" />
        </filter>
      </defs>
      
      <path
        d="M50 10 
           C50 10 20 50 20 80 
           C20 100 33 115 50 115 
           C67 115 80 100 80 80 
           C80 50 50 10 50 10Z"
        fill="url(#dropGradient)"
        stroke="hsl(200, 70%, 40%)"
        strokeWidth="2"
        filter="url(#dropShadow)"
        className={animated ? "animate-pulse" : ""}
        style={animated ? { animationDuration: "3s" } : undefined}
      />
      
      <ellipse
        cx="38"
        cy="70"
        rx="6"
        ry="10"
        fill="rgba(255, 255, 255, 0.4)"
        transform="rotate(-15 38 70)"
      />
      
      <ellipse
        cx="42"
        cy="55"
        rx="3"
        ry="5"
        fill="rgba(255, 255, 255, 0.5)"
        transform="rotate(-15 42 55)"
      />
    </svg>
  );
}
