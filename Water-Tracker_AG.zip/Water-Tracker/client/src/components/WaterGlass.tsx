import { useWaterTracker } from "@/context/WaterTrackerContext";

interface WaterGlassProps {
  size?: "small" | "medium" | "large";
  showMilestones?: boolean;
}

export function WaterGlass({ size = "large", showMilestones = true }: WaterGlassProps) {
  const { getProgress, getMilestone } = useWaterTracker();
  const progress = getProgress();
  const milestone = getMilestone();

  const sizeClasses = {
    small: "w-16 h-20",
    medium: "w-24 h-32",
    large: "w-32 h-44",
  };

  return (
    <div className="flex items-center gap-6">
      <div className={`relative ${sizeClasses[size]}`}>
        <svg
          viewBox="0 0 100 130"
          className="w-full h-full"
          aria-label={`Water glass showing ${progress}% filled`}
        >
          <defs>
            <clipPath id="glassClip">
              <path d="M15 10 L85 10 L80 120 L20 120 Z" />
            </clipPath>
            <linearGradient id="waterGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="hsl(195, 85%, 70%)" />
              <stop offset="100%" stopColor="hsl(200, 85%, 50%)" />
            </linearGradient>
            <pattern id="wavePattern" patternUnits="userSpaceOnUse" width="100" height="8" x="0" y="0">
              <path
                d="M0 4 Q25 0 50 4 T100 4"
                fill="none"
                stroke="hsl(195, 85%, 80%)"
                strokeWidth="2"
                opacity="0.5"
              >
                <animate
                  attributeName="d"
                  values="M0 4 Q25 0 50 4 T100 4;M0 4 Q25 8 50 4 T100 4;M0 4 Q25 0 50 4 T100 4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </path>
            </pattern>
          </defs>

          <path
            d="M15 10 L85 10 L80 120 L20 120 Z"
            fill="none"
            stroke="hsl(var(--border))"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          <g clipPath="url(#glassClip)">
            <rect
              x="15"
              y={120 - (progress * 1.1)}
              width="70"
              height={progress * 1.1 + 10}
              fill="url(#waterGradient)"
              className="transition-all duration-700 ease-out"
            />
            <rect
              x="15"
              y={120 - (progress * 1.1) - 4}
              width="70"
              height="8"
              fill="url(#wavePattern)"
              className="transition-all duration-700 ease-out"
            />
          </g>

          <ellipse
            cx="50"
            cy="10"
            rx="35"
            ry="4"
            fill="none"
            stroke="hsl(var(--border))"
            strokeWidth="2"
          />
        </svg>
      </div>

      {showMilestones && (
        <div className="flex flex-col gap-2">
          {[4, 3, 2, 1].map((m) => (
            <div
              key={m}
              className={`flex items-center gap-2 text-sm transition-colors duration-300 ${
                milestone >= m ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-md border-2 flex items-center justify-center transition-all duration-300 ${
                  milestone >= m
                    ? "border-primary bg-primary/10"
                    : "border-muted bg-muted/30"
                }`}
              >
                <GlassIcon fillLevel={m} active={milestone >= m} />
              </div>
              <span className="text-xs font-medium">{m * 25}%</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function GlassIcon({ fillLevel, active }: { fillLevel: number; active: boolean }) {
  const fillHeight = fillLevel * 25;
  
  return (
    <svg viewBox="0 0 20 24" className="w-4 h-5">
      <defs>
        <clipPath id={`miniClip-${fillLevel}`}>
          <path d="M3 2 L17 2 L16 22 L4 22 Z" />
        </clipPath>
      </defs>
      <path
        d="M3 2 L17 2 L16 22 L4 22 Z"
        fill="none"
        stroke={active ? "hsl(var(--primary))" : "hsl(var(--muted))"}
        strokeWidth="1.5"
      />
      <g clipPath={`url(#miniClip-${fillLevel})`}>
        <rect
          x="3"
          y={22 - (fillHeight * 0.8)}
          width="14"
          height={fillHeight * 0.8 + 2}
          fill={active ? "hsl(var(--primary))" : "hsl(var(--muted))"}
          opacity={active ? 0.6 : 0.3}
        />
      </g>
    </svg>
  );
}
