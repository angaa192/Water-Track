import { type ReactNode } from "react";
import { Link } from "wouter";
import { Home } from "lucide-react";
import { BottomNav } from "./BottomNav";
import { Button } from "@/components/ui/button";

interface PageLayoutProps {
  children: ReactNode;
  showNav?: boolean;
  showHomeButton?: boolean;
  title?: string;
}

export function PageLayout({ 
  children, 
  showNav = true, 
  showHomeButton = true,
  title 
}: PageLayoutProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {showHomeButton && (
        <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
          <div className="max-w-md mx-auto px-6 py-3 flex items-center gap-3">
            <Link href="/">
              <Button 
                variant="ghost" 
                size="icon" 
                data-testid="button-home"
                aria-label="Go to home page"
              >
                <Home className="w-5 h-5" />
              </Button>
            </Link>
            {title && (
              <h1 className="text-lg font-semibold text-foreground">{title}</h1>
            )}
          </div>
        </header>
      )}
      
      <main className={`flex-1 ${showNav ? "pb-20" : ""}`}>
        {children}
      </main>
      
      {showNav && <BottomNav />}
    </div>
  );
}
