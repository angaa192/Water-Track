import { 
  type User, 
  type InsertUser, 
  type WaterIntake, 
  type InsertWaterIntake,
  type DailyTracking,
  type InsertDailyTracking 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Water intake methods
  addWaterIntake(intake: InsertWaterIntake): Promise<WaterIntake>;
  getWaterIntakes(date: string): Promise<WaterIntake[]>;
  
  // Daily tracking methods
  getDailyTracking(date: string): Promise<DailyTracking | undefined>;
  createOrUpdateDailyTracking(tracking: InsertDailyTracking): Promise<DailyTracking>;
  updateDailyTracking(date: string, updates: Partial<InsertDailyTracking>): Promise<DailyTracking | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private waterIntakes: Map<string, WaterIntake>;
  private dailyTracking: Map<string, DailyTracking>;

  constructor() {
    this.users = new Map();
    this.waterIntakes = new Map();
    this.dailyTracking = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async addWaterIntake(intake: InsertWaterIntake): Promise<WaterIntake> {
    const id = randomUUID();
    const waterIntake: WaterIntake = {
      ...intake,
      id,
      createdAt: new Date(),
    };
    this.waterIntakes.set(id, waterIntake);
    return waterIntake;
  }

  async getWaterIntakes(date: string): Promise<WaterIntake[]> {
    const intakes = Array.from(this.waterIntakes.values()).filter((intake) => {
      if (!intake.createdAt) return false;
      const intakeDate = new Date(intake.createdAt).toISOString().split("T")[0];
      return intakeDate === date;
    });
    return intakes;
  }

  async getDailyTracking(date: string): Promise<DailyTracking | undefined> {
    return this.dailyTracking.get(date);
  }

  async createOrUpdateDailyTracking(tracking: InsertDailyTracking): Promise<DailyTracking> {
    const existing = this.dailyTracking.get(tracking.date);
    
    if (existing) {
      const updated: DailyTracking = {
        ...existing,
        ...tracking,
      };
      this.dailyTracking.set(tracking.date, updated);
      return updated;
    }

    const id = randomUUID();
    const newTracking: DailyTracking = {
      id,
      date: tracking.date,
      goalMl: tracking.goalMl ?? 2000,
      totalMl: tracking.totalMl ?? 0,
      frequency: tracking.frequency ?? null,
      mood: tracking.mood ?? null,
      waterType: tracking.waterType ?? null,
    };
    this.dailyTracking.set(tracking.date, newTracking);
    return newTracking;
  }

  async updateDailyTracking(date: string, updates: Partial<InsertDailyTracking>): Promise<DailyTracking | undefined> {
    const existing = this.dailyTracking.get(date);
    if (!existing) return undefined;

    const updated: DailyTracking = {
      ...existing,
      ...updates,
    };
    this.dailyTracking.set(date, updated);
    return updated;
  }
}

export const storage = new MemStorage();
