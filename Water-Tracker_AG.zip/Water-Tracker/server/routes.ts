import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaterIntakeSchema, insertDailyTrackingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get today's date in YYYY-MM-DD format
  const getTodayDate = () => new Date().toISOString().split("T")[0];

  // Add water intake
  app.post("/api/water-intake", async (req, res) => {
    try {
      const parsed = insertWaterIntakeSchema.parse(req.body);
      const intake = await storage.addWaterIntake(parsed);
      
      // Update daily tracking total
      const today = getTodayDate();
      const dailyTracking = await storage.getDailyTracking(today);
      
      if (dailyTracking) {
        await storage.updateDailyTracking(today, {
          totalMl: dailyTracking.totalMl + parsed.amount,
        });
      } else {
        await storage.createOrUpdateDailyTracking({
          date: today,
          totalMl: parsed.amount,
          goalMl: 2000,
        });
      }
      
      res.json(intake);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: "Failed to add water intake" });
      }
    }
  });

  // Get water intakes for a specific date
  app.get("/api/water-intake/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const intakes = await storage.getWaterIntakes(date);
      res.json(intakes);
    } catch (error) {
      res.status(500).json({ error: "Failed to get water intakes" });
    }
  });

  // Get daily tracking data
  app.get("/api/daily-tracking/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const tracking = await storage.getDailyTracking(date);
      
      if (!tracking) {
        // Return default tracking for the date
        res.json({
          date,
          goalMl: 2000,
          totalMl: 0,
          frequency: null,
          mood: null,
          waterType: null,
        });
        return;
      }
      
      res.json(tracking);
    } catch (error) {
      res.status(500).json({ error: "Failed to get daily tracking" });
    }
  });

  // Update daily tracking
  app.patch("/api/daily-tracking/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const updates = req.body;
      
      let tracking = await storage.getDailyTracking(date);
      
      if (!tracking) {
        tracking = await storage.createOrUpdateDailyTracking({
          date,
          ...updates,
        });
      } else {
        tracking = await storage.updateDailyTracking(date, updates);
      }
      
      res.json(tracking);
    } catch (error) {
      res.status(500).json({ error: "Failed to update daily tracking" });
    }
  });

  // Get today's tracking data
  app.get("/api/daily-tracking", async (req, res) => {
    try {
      const today = getTodayDate();
      const tracking = await storage.getDailyTracking(today);
      
      if (!tracking) {
        res.json({
          date: today,
          goalMl: 2000,
          totalMl: 0,
          frequency: null,
          mood: null,
          waterType: null,
        });
        return;
      }
      
      res.json(tracking);
    } catch (error) {
      res.status(500).json({ error: "Failed to get daily tracking" });
    }
  });

  return httpServer;
}
