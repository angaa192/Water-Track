# Water Tracker Application

## Overview

A mobile-first water tracking application that helps users monitor their daily hydration. Users can log water intake, set daily goals, track drinking frequency, record their mood, and specify the type of water consumed. The app features animated visualizations including a water glass with fill animations and progress indicators.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Context API (WaterTrackerContext) for global water tracking state, TanStack React Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming, mobile-first responsive design
- **Build Tool**: Vite with React plugin

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript compiled with tsx
- **API Pattern**: RESTful JSON API under `/api` prefix
- **Data Validation**: Zod schemas shared between client and server via drizzle-zod

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Current Storage**: In-memory storage implementation (MemStorage class) that can be swapped for database storage
- **Database Ready**: Drizzle configuration expects `DATABASE_URL` environment variable for PostgreSQL connection

### Key Data Models
- **Users**: Basic authentication with username/password
- **Water Intakes**: Individual water consumption records with amount (ml), water type, and timestamp
- **Daily Tracking**: Aggregated daily data including goals, totals, frequency, mood, and preferred water type

### Application Pages
1. **Home** (`/`): Landing page with animated water droplet
2. **Daily Goal** (`/daily-goal`): Water glass visualization with progress tracking and quick-add buttons
3. **Frequency** (`/frequency`): Track how many times per day user drinks water
4. **Mood** (`/mood`): Log daily mood (sad, neutral, happy)
5. **Type** (`/type`): Select water type preference (still, carbonated, flavored)

### Design System
- Mobile-first single-column layouts with `max-w-md` container
- Fixed bottom navigation with four tabs
- Custom water glass SVG component with animated fill effects
- Consistent spacing using Tailwind's spacing scale

## External Dependencies

### UI Libraries
- Radix UI primitives for accessible components
- Lucide React for icons
- Embla Carousel for carousel functionality
- Vaul for drawer components
- class-variance-authority for component variants

### Data & State
- TanStack React Query for async data fetching
- Zod for runtime type validation
- date-fns for date manipulation

### Database & ORM
- Drizzle ORM for database operations
- drizzle-zod for generating Zod schemas from Drizzle tables
- PostgreSQL as the target database (requires DATABASE_URL)
- connect-pg-simple for session storage (if sessions needed)

### Build & Development
- Vite for frontend bundling with HMR
- esbuild for server bundling
- tsx for TypeScript execution during development