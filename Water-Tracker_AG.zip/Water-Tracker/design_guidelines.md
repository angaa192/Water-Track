# Water Tracker Application - Design Guidelines

## Design Approach
**Utility-Focused Health Application** - This water tracking app prioritizes clarity, ease of use, and motivational feedback. The design follows a clean, single-purpose interface pattern where each page focuses on one specific tracking action.

## Layout System

**Mobile-First Single Column Layout**
- All pages use centered, single-column layouts optimized for mobile interaction
- Maximum content width: `max-w-md` (448px) centered with `mx-auto`
- Consistent page padding: `p-6` for mobile, `p-8` for larger screens
- Full-height pages using `min-h-screen` to create focused, card-like experiences

**Spacing System**
Primary spacing units: `4, 6, 8, 12, 16` for consistent vertical rhythm
- Section spacing: `mb-8` to `mb-12` between major sections
- Component spacing: `mb-4` to `mb-6` for related elements
- Button spacing: `gap-4` between action buttons

## Typography

**Font Family**: System font stack for optimal performance
```
font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif
```

**Hierarchy**:
- Page Titles: `text-2xl` to `text-3xl`, `font-bold`, centered
- Section Headers: `text-xl`, `font-semibold`
- Body Text: `text-base`, regular weight
- Descriptive Labels: `text-sm`, `text-gray-600`
- Large Display Numbers: `text-5xl` to `text-6xl`, `font-bold` for water goals/progress

## Component Library

### Navigation Tabs
- Fixed bottom navigation with 4 tabs: Daily Goal, Frequency, Mood, Type
- Icon + label format, vertical layout within each tab
- Active state: Blue accent color, inactive: Gray
- Spacing: Equal distribution using flexbox, `py-3`

### Progress Visualization
- **Water Glass Component**: SVG-based glass container with animated fill effect
- Positioned centrally, large size (`w-32` to `w-40`)
- Fill animation using CSS transitions on height/transform
- Milestone markers (25%, 50%, 75%, 100%) positioned alongside glass

### Input Buttons
- **Quick Action Buttons**: Large tap targets, `min-h-12` to `min-h-14`
- Rounded corners: `rounded-lg`
- Three-button grid for water amounts (+200ml, +400ml, +600ml)
- Full-width buttons for primary actions
- Button group spacing: `gap-3` to `gap-4`

### Selection Options
- **Frequency Selector**: 4 radio-style buttons (1-4 times)
- **Mood Selector**: 3 large emoji buttons (sad/neutral/happy) with color coding
- **Water Type**: 3 option cards (still/carbonated/flavored)
- All selectors use clear visual states (selected vs unselected borders/backgrounds)

### Progress Indicator
- Horizontal progress bar showing daily goal completion
- Height: `h-3` to `h-4`, fully rounded (`rounded-full`)
- Percentage text displayed prominently below
- Background track in light gray, filled portion in blue

## Interactive Patterns

**Single-Tap Actions**: All primary interactions require single tap/click
**Visual Feedback**: Immediate state changes on selection (border changes, background fills)
**No Hover States**: Optimized for touch, focus on active/selected states only
**Modal-Style Pages**: Each page acts as a focused step in the tracking flow

## Icons
Use **Heroicons** (outline style) via CDN for:
- Water droplet icon (home/branding)
- Navigation icons (calendar, repeat, emoji, beaker)
- Plus/minus icons for increment buttons

## Images
**No hero images required** - This is a utility app focused on functionality. The water droplet icon serves as the primary visual branding element on the home page.

## Color Palette Notes
Colors will be specified separately, but the design uses:
- Primary action color (blue theme)
- Success/progress indicators
- Neutral backgrounds and borders
- Mood-based colors (red/yellow/green for emoji states)

## Accessibility
- Large tap targets (minimum 44x44px)
- Clear visual states for all interactive elements
- High contrast text on all backgrounds
- Semantic HTML with proper ARIA labels for icon-only buttons