import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Water Tracker Schema
export const waterIntakes = pgTable("water_intakes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  amount: integer("amount").notNull(), // in ml
  waterType: text("water_type").notNull().default("still"), // still, carbonated, flavored
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWaterIntakeSchema = createInsertSchema(waterIntakes).omit({
  id: true,
  createdAt: true,
});

export type InsertWaterIntake = z.infer<typeof insertWaterIntakeSchema>;
export type WaterIntake = typeof waterIntakes.$inferSelect;

// Daily Tracking Data
export const dailyTracking = pgTable("daily_tracking", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: text("date").notNull(), // YYYY-MM-DD format
  goalMl: integer("goal_ml").notNull().default(2000), // default 2L
  totalMl: integer("total_ml").notNull().default(0),
  frequency: integer("frequency").default(0), // times per day
  mood: text("mood"), // sad, neutral, happy
  waterType: text("water_type"), // still, carbonated, flavored
});

export const insertDailyTrackingSchema = createInsertSchema(dailyTracking).omit({
  id: true,
});

export type InsertDailyTracking = z.infer<typeof insertDailyTrackingSchema>;
export type DailyTracking = typeof dailyTracking.$inferSelect;

// TypeScript interfaces for frontend state
export interface WaterTrackerState {
  currentIntake: number;
  dailyGoal: number;
  frequency: number | null;
  mood: "sad" | "neutral" | "happy" | null;
  waterType: "still" | "carbonated" | "flavored" | null;
}

export const WATER_AMOUNTS = [200, 400, 600] as const;
export const FREQUENCY_OPTIONS = [1, 2, 3, 4] as const;
export const MOOD_OPTIONS = ["sad", "neutral", "happy"] as const;
export const WATER_TYPES = ["still", "carbonated", "flavored"] as const;
